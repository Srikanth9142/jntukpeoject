function myEvent1(){
    window.location.href="test.html";
}

function myEvent2(){
    window.location.href="test.html";
}

function myEvent3(){
    window.location.href="test.html";
}

function myEvent4(){
    window.location.href="test.html";
}
function myEvent5(){
    window.location.href="test.html";
}

function myEvent6(){
    window.location.href="test.html";
}

function myEvent7(){
    window.location.href="test.html";
}

function myEvent8(){
    window.location.href="test.html";
}